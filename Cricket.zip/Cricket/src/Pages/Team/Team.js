import axios from 'axios'
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { BaseUrl } from '../../BaseUrl'
import { setUserData } from '../../Redux/Redux'

const Team = () => {
  const { userData } = useSelector(state => state.cricketers)
  // console.log('userData👍', userData)
  const dispatch = useDispatch()

  const getUserData = async () => {
    const URL = `${BaseUrl}/players`
    const data = await axios.get(URL)
    dispatch(setUserData(data.data))
    // console.log('data👍', data.data)
  }

  useEffect(() => {
    getUserData()
  }, [])

  return (
    <section className="text-gray-600 body-font">
      <div className="container px-5 py-24 mx-auto">
        <div className="flex flex-wrap -m-4">
          {userData.map((item, index) => {
            return (
              <div key={index} className="lg:w-1/4 md:w-1/2 p-4 w-full">
                <Link to={`/players/${item.id}`}>
                  <div className="border-solid border-2 border-indigo-600 p-5 rounded">
                    <img
                      alt="ecommerce"
                      className="w-full h-74 border-solid border-2"
                      src={item.image}
                    />
                    <div className="mt-4">
                      <p>
                        <span className="font-semibold text-base">Name: </span>
                        {item.name}
                      </p>
                      <p>
                        <span className="font-semibold text-base">Category: </span>
                        {item.category}
                      </p>
                      <p>
                        <span className="font-semibold text-base">Country: </span>
                        {item.country}
                      </p>
                      <p>
                        <span className="font-semibold text-base">Price: </span>
                        {item.auctionprice}
                      </p>
                    </div>
                  </div>
                </Link>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default Team
