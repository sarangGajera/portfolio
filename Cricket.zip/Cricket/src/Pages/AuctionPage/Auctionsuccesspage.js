import React from "react";
import { useSelector } from "react-redux";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";

const Auctionsuccesspage = () => {
  const { franchiseData } = useSelector((state) => state.cricketers);
  const { Auctsucdataplayerdata } = useSelector((state) => state.cricketers);

  let totalauction = Auctsucdataplayerdata.map(function (item) {
    return parseInt(item.auctionprice);
  });
  const Totalauction = totalauction
    .map((item) => item)
    .reduce((item, index) => item + index);

  return (
    <div className="auctionsuccess">
      <Navbar />
      <div className="container my-12">
        <div className="auction_div">
          <h1 className="font-bold text-[#07bc0c] text-5xl flex justify-center text-center">
            Your Auction has been completed Successfully
          </h1>
        </div>
        <div className="auction_success border-2 border-indigo-600 my-12">
          <div className="text-center">
            <hr className="border-1 border-indigo-600" />
            <h1 className="font-semibold text-base text-3xl m-4">
              Franchise Details
            </h1>
            <hr className="border-1 border-indigo-600" />
          </div>
          <div className="flex">
            <div className="mt-4 ml-14">
              <h1 className="font-semibold text-base">Franchise Name :</h1>
              <h1 className="font-semibold text-base">Owner Name :</h1>
              <h1 className="font-semibold text-base">Email ID :</h1>
              <h1 className="font-semibold text-base">Phone Number :</h1>
              <h1 className="font-semibold text-base">Franchise Location :</h1>
            </div>
            <div className="mt-4 ml-14">
              <h3>{franchiseData.franchisename}</h3>
              <h3>{franchiseData.ownername}</h3>
              <h3>{franchiseData.email}</h3>
              <h3>{franchiseData.phonenumber}</h3>
              <h3>{franchiseData.franchiselocation}</h3>
            </div>
          </div>

          <div className="text-center my-6">
            <hr className="border-1 border-indigo-600" />
            <h1 className="font-semibold text-base text-3xl m-4">
              Players Details
            </h1>
            <hr className="border-1 border-indigo-600" />
          </div>
          <div className="">
            <div className="">
              <div className="flex ml-14">
                <h1 className="font-semibold text-base">Players Name:</h1>
                {Auctsucdataplayerdata.map((event, index) => {
                  return (
                    <div key={index}>
                      <h1 className="ml-14">{event.name},</h1>
                    </div>
                  );
                })}
              </div>
              <div className="flex ml-14">
                <h1 className="font-semibold text-base">Total Price:</h1>
                <span className="ml-20">{Totalauction}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Auctionsuccesspage;
