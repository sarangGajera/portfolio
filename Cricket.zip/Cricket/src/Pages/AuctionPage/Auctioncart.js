import React from "react";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "yup-phone";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setFranchiseData } from "../../Redux/Redux";

const initialInput = {
  franchisename: '',
  ownername: '',
  email: '',
  phonenumber: '',
  franchiselocation: ''
}

const Auctioncart = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const validInput = Yup.object({
    email: Yup.string().email("Invalid  email fromat").required("Required!"),
    franchisename: Yup.string().required("Required!"),
    ownername: Yup.string().required("Required!"),
    phonenumber: Yup.string().phone(null, "Required!").required("Required!"),
    franchiselocation: Yup.string().required("Required!"),
  });

  const onSubmit = (value) => {
    dispatch(setFranchiseData(value));
    navigate("/auctionsuccess");
  };

  return (
    <div className="auctioncart">
      <Navbar />
      <div className="container flex justify-center my-12">
        <div className="my-7 auction_cart">
          <Formik
            initialValues={initialInput}
            validationSchema={validInput}
            onSubmit={onSubmit}
          >
            <Form className="w-full max-w-lg border-2 border-indigo-600 p-6 rounded">
              <div className="flex flex-wrap -mx-3 mb-6">
                <div className="w-full px-3">
                  <label
                    className="block tracking-wide text-gray-700 mb-2 font-semibold text-base"
                    htmlFor="grid-text"
                  >
                    Franchise Name :
                  </label>
                  <Field
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-2 px-4 mb-2 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    id="grid-text"
                    type="text"
                    placeholder="Enter Franchise Name"
                    name="franchisename"
                  />
                  <ErrorMessage className="mb-3" name="franchisename">
                    {errorMsg => <div className="error text-red-600">{errorMsg}</div>}
                  </ErrorMessage>
                </div>

                <div className="w-full px-3">
                  <label
                    className="block tracking-wide text-gray-700 mb-2 font-semibold text-base"
                    htmlFor="grid-text"
                  >
                    Owner Name :
                  </label>
                  <Field
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-2 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    id="grid-text"
                    type="text"
                    placeholder="Enter Owner Name"
                    name="ownername"
                  />
                  <ErrorMessage className="mb-3" name="ownername">
                    {errorMsg => <div className="error text-red-600">{errorMsg}</div>}
                  </ErrorMessage>
                </div>

                <div className="w-full px-3">
                  <label
                    className="block tracking-wide text-gray-700 mb-2 font-semibold text-base"
                    htmlFor="grid-email"
                  >
                    Email ID :
                  </label>
                  <Field
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-2 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    id="grid-email"
                    type="email"
                    placeholder="Enter Emial ID"
                    name="email"
                  />
                  <ErrorMessage className="mb-3" name="email">
                    {errorMsg => <div className="error text-red-600">{errorMsg}</div>}
                  </ErrorMessage>
                </div>

                <div className="w-full px-3">
                  <label
                    className="block tracking-wide text-gray-700 mb-2 font-semibold text-base"
                    htmlFor="grid-number"
                  >
                    Phone Number :
                  </label>
                  <Field
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-2 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    id="grid-number"
                    type="tel"
                    placeholder="Enter Phone Number"
                    maxLength="10"
                    minLength="10"
                    onKeyPress={event => {
                      if (!/[0-9]/.test(event.key)) {
                        event.preventDefault()
                      }
                    }}
                    name="phonenumber"
                  />
                  <ErrorMessage className="mb-3" name="phonenumber">
                    {errorMsg => <div className="error text-red-600">{errorMsg}</div>}
                  </ErrorMessage>
                </div>

                <div className="w-full px-3">
                  <label
                    className="block tracking-wide text-gray-700 mb-2 font-semibold text-base"
                    htmlFor="grid-text"
                  >
                    Franchise Location :
                  </label>
                  <Field
                    className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                    id="grid-text"
                    type="text"
                    placeholder="Enter Franchise Location"
                    name="franchiselocation"
                  />
                  <ErrorMessage className="" name="franchiselocation">
                    {errorMsg => <div className="error text-red-600">{errorMsg}</div>}
                  </ErrorMessage>
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded focus:outline-none mx-auto flex justify-center"
              >
                Checkout
              </button>
            </Form>
          </Formik>
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Auctioncart
