import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import { clearCart, deletePlayers } from "../../Redux/Redux";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Cart = () => {
  const dispatch = useDispatch();
  const { auctionCart } = useSelector((state) => state.cricketers);

  const cartPlayerDelete = (id) => {
    dispatch(deletePlayers(id));
    toast.success("This Player Delete Successfully .", {
      position: "top-right",
      autoClose: 500,
    });
  };

  return (
    <div>
      <Navbar />
      <div className="container mx-auto">
        <div className="flex justify-end items-end">
          <button
            className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded m-2"
            onClick={() => dispatch(clearCart())}
          >
            Empty Cart
          </button>
          <Link to="/auctioncart">
            <button
              onClick={() => dispatch(clearCart())}
              className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded m-2"
            >
              Close Auction
            </button>
          </Link>
        </div>
        {!auctionCart.length ? (
          <div className="flex justify-center items-center lg:my-60 md:my-44">
            <h1 className="text-4xl font-semibold">
              No players are added to the cart
            </h1>
          </div>
        ) : (
          <section className="text-gray-600 body-font">
            <div className="container px-5 py-24 mx-auto">
              <div className="flex flex-wrap -m-4">
                {auctionCart.map((item, index) => {
                  return (
                    <div key={index} className="lg:w-1/4 md:w-1/2 p-4 w-full">
                      <div className="border-solid border-2 border-indigo-600 p-5 rounded">
                        <img
                          alt="ecommerce"
                          className="w-full h-74 border-solid border-2"
                          src={item.image}
                        />
                        <div className="mt-4">
                          <p>
                            <span className="font-semibold text-base">
                              Name:{" "}
                            </span>
                            {item.name}
                          </p>
                          <p>
                            <span className="font-semibold text-base">
                              Category:{" "}
                            </span>
                            {item.category}
                          </p>
                          <p>
                            <span className="font-semibold text-base">
                              Country:{" "}
                            </span>
                            {item.country}
                          </p>
                          <p>
                            <span className="font-semibold text-base">
                              Price:{" "}
                            </span>
                            {item.auctionprice}
                          </p>
                        </div>
                        <div className="py-4">
                          <button
                            className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded focus:outline-none mx-auto flex justify-center"
                            onClick={() => cartPlayerDelete(item.id)}
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Cart;
