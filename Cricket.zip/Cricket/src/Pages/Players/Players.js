import axios from "axios";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { BaseUrl } from "../../BaseUrl";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import {
  playersDetails,
  setAuctionCartData,
  setAuctionplaydata,
} from "../../Redux/Redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Players = () => {
  const { id } = useParams();
  const { playersData } = useSelector((state) => state.cricketers);
  const { auctionCart } = useSelector((state) => state.cricketers);
  const dispatch = useDispatch();

  const getPlayersData = async (id) => {
    const URL = `${BaseUrl}/players/${id}`;
    const data = await axios.get(URL);
    dispatch(playersDetails(data.data));
  };

  useEffect(() => {
    getPlayersData(id);
  }, []);

  const addToCart = () => {
    const index = auctionCart.findIndex((item) => item.id === playersData.id);
    const cart = auctionCart.length;

    let count = 0;
    //Batsman...okay
    if (playersData.category === "Batsman") {
      auctionCart.map((item) => {
        if (item.category === "Batsman") {
          count++;
        }
      });
      if (count >= 6) {
        toast.error("Sorry, Maximum 7 Batsman Player Added.", {
          position: "top-right",
          autoClose: 500,
        });
        return;
      }
    }

    //Bowler...okay
    if (playersData.category === "Bowler") {
      auctionCart.map((item) => {
        if (item.category === "Bowler") {
          count++;
        }
      });
      if (count >= 3) {
        toast.error("Sorry, Maximum 4 Bowler Player Added.", {
          position: "top-right",
          autoClose: 500,
        });
        return;
      }
    }

    //Wicketkeeper...okay
    if (playersData.category === "Keeper Batsman") {
      auctionCart.map((item) => {
        if (item.category === "Keeper Batsman") {
          count++;
        }
      });
      if (count >= 1) {
        toast.error("Sorry, Maximum 2 Keeper Batsman Player Added.", {
          position: "top-right",
          autoClose: 500,
        });
        return;
      }
    }

    //Allrounder...okay
    if (playersData.category === "allrounder") {
      auctionCart.map((item) => {
        if (item.category === "allrounder") {
          count++;
        }
      });
      if (count >= 1) {
        toast.error("Sorry, Maximum 2 allrounder Player Added.", {
          position: "top-right",
          autoClose: 500,
        });
        return;
      }
    }

    //Dispetch Player Added...
    if (cart > 14) {
      toast.error("Sorry, Maximum 15 Player Only.", {
        position: "top-right",
        autoClose: 500,
      });
    } else {
      if (index === -1) {
        dispatch(setAuctionCartData(playersData));
        dispatch(setAuctionplaydata(playersData));
        toast.success("This Player Is Added.", {
          position: "top-right",
          autoClose: 500,
        });
      } else {
        toast.error("Sorry, This Player Is All Ready Added.", {
          position: "top-right",
          autoClose: 500,
        });
      }
    }
  };

  return (
    <div>
      <Navbar />
      <div className="container flex justify-center my-12">
        <div className="lg:w-1/4 md:w-1/2 p-4 w-full">
          <a className="block relative w-72 rounded overflow-hidden border-solid border-2 border-indigo-600 p-5">
            <img
              className="object-cover object-center w-full h-full block border-solid border-2"
              src={playersData.image}
              alt="Team Member"
            />
            <p>
              <span className="font-semibold text-base">Name: </span>
              {playersData.name}
            </p>
            <p>
              <span className="font-semibold text-base">Category: </span>
              {playersData.category}
            </p>
            <p>
              <span className="font-semibold text-base">Country: </span>
              {playersData.country}
            </p>
            <p>
              <span className="font-semibold text-base">Price: </span>
              {playersData.auctionprice}
            </p>
            <div className="py-4">
              <button
                className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded focus:outline-none mx-auto flex justify-center"
                onClick={addToCart}
              >
                Add to Auction Cart
              </button>
              <ToastContainer />
            </div>
          </a>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Players;
