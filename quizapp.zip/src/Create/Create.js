import React, { useState } from "react";
import Header from "../Component/Header";
import Footer from "../Component/Footer";
import { useDispatch } from "react-redux";
import { setQuestiosn } from "../Redux/Reduacer";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";

const Create = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [formError, setFormError] = useState({});
  const [formErrors, setFormErrors] = useState({});
  const [formErrore, setFormErrore] = useState({});
  const [opetionTypes, setOpetionTypes] = useState("single");
  const [single, setSingle] = useState("");
  const [checkbox, setCheckbox] = useState("");
  const [inputList, setInputList] = useState([
    {
      input: "",
      id: 1,
      status: false,
    },
  ]);
  const [questionarray, setQuestionarray] = useState({
    question: "",
    opetionType: opetionTypes,
    opetion: [],
    selectAns: [],
  });
  const [quizobject, setQuizobject] = useState({
    title: "",
    questions: [],
  });

  const onchangObject = (event) => {
    if (event.target.name === "languages") {
      var copy = { ...quizobject };

      if (event.target.checked) {
        copy.languages.push(event.target.value);
      } else {
        copy.languages = copy.languages.filter(
          (el) => el !== event.target.value
        );
      }

      setQuizobject(copy);
    } else {
      setQuizobject(() => ({
        ...quizobject,
        [event.target.name]: event.target.value,
      }));
    }
  };

  const validateForm = () => {
    var err = {};
    if (quizobject.title === "") {
      err.title = "Title is required!";
    }

    setFormError({ ...err });

    return Object.keys(err).length < 1;
  };

  const onchangArray = (event) => {
    if (event.target.name === "languagess") {
      var copys = { ...questionarray };

      if (event.target.checked) {
        copys.languagess.push(event.target.value);
      } else {
        copys.languages = copys.languagess.filter(
          (el) => el !== event.target.value
        );
      }

      setQuestionarray(copys);
    } else {
      setQuestionarray(() => ({
        ...questionarray,
        [event.target.name]: event.target.value,
      }));
    }
  };

  const validateForms = () => {
    var errs = {};
    if (questionarray.question === "") {
      errs.question = "Question is required!";
    }

    setFormErrors({ ...errs });

    return Object.keys(errs).length < 1;
  };

  const onChangopetionType = (event, index) => {
    setOpetionTypes(event.target.value);
    setQuestionarray({ ...questionarray, opetionType: event.target.value });
    let data = inputList.map((item) => {
      return { ...item, status: false };
    });
    setInputList(data);
  };

  const onchanSingle = (event, index, id) => {
    const SingleData = [...inputList];
    let SingleObj = SingleData.map((item, i) => {
      if (i === index) {
        return {
          ...item,
          status: true,
        };
      } else {
        return {
          ...item,
          status: false,
        };
      }
    });
    var radiolist = [...SingleObj];
    if (event.target.checked) {
      radiolist = [id];
    } else {
      radiolist.splice(single.indexOf(event.target.value), 1);
    }
    setInputList(SingleObj);
    setSingle(radiolist);
    setQuestionarray({
      ...questionarray,
      selectAns: [radiolist],
      opetion: SingleObj,
    });
  };

  const onChangMultiple = (event, index) => {
    var multipleData = [...inputList];
    const muData = multipleData.map((item, i) => {
      if (i === index) {
        return {
          ...item,
          status: !item.status,
        };
      } else {
        return {
          ...item,
        };
      }
    });
    muData[index] = { ...muData[index], status: event.target.checked };
    var updatedList = [...checkbox];
    if (event.target.checked) {
      updatedList = [...checkbox, parseInt(event.target.value)];
    } else {
      updatedList.splice(checkbox.indexOf(event.target.value), 2);
    }
    setInputList(muData);
    setCheckbox(updatedList);
    setQuestionarray({
      ...questionarray,
      selectAns: [updatedList],
      opetion: muData,
    });
  };

  const handleListAdd = () => {
    if (inputList.length < 4) {
      setInputList([
        ...inputList,
        {
          input: "",
          id: 1,
          status: false,
        },
      ]);
    }
  };

  const handleInputChange = (event, index) => {
    if (event.target === "languagese") {
      var copye = [...inputList];

      if (event.target.checked) {
        copye.languagese.push(event.target.value);
      } else {
        copye.languagese = copye.languagese.filter(
          (el) => el !== event.target.value
        );
      }

      setInputList(copye);
    } else {
      setInputList(() => ({
        ...inputList,
        [event.target.name]: event.target.value,
      }));
    }
    const value = event.target.value;

    const newInputList = [...inputList];
    newInputList[index].input = value;
    newInputList[index].id = index + 1;
    setInputList(newInputList);
  };

  const validateForme = (index) => {
    var erre = {};

    inputList.map((item) => {
      if (item.input === "") {
        erre.input = "Opetion is required!";
      }
    });

    setFormErrore({ ...erre });

    return Object.keys(erre).length < 1;
  };

  const removeInput = (id) => {
    const newText = inputList.filter((text) => text.id !== id, 1);
    setInputList(newText);
  };

  const onNextbtn = (event) => {
    event.preventDefault();
    var questionsValid = validateForms();
    var inputListValid = validateForme();
    let dummyData = [];
    inputList.map((item) => {
      dummyData.push(item.input);
    });
    let demos = dummyData.filter(
      (item, index, arr) => arr.indexOf(item) !== index
    );

    if (demos.length > 0) {
      toast.error("Already Same Answer Added!", {
        position: "top-right",
        autoClose: 1700,
      });
      return;
    }
    if (
      questionsValid &&
      inputListValid &&
      questionarray.selectAns.length > 0 &&
      inputList.length > 1
    ) {
      toast.success("Successfully Question Submitted", {
        position: "top-right",
        autoClose: 1700,
      });
      setQuizobject({
        ...quizobject,
        questions: [...quizobject.questions, { questionarray }],
      });
      setQuestionarray({
        question: "",
        opetionType: opetionTypes,
        opetion: [],
        selectAns: [],
      });
      setInputList([
        {
          input: "",
          id: 1,
          status: false,
        },
      ]);
      setCheckbox("");
    } else {
      toast.error(
        "Please Input Field and SelectAns and max 2 Answer is Required!",
        {
          position: "top-right",
          autoClose: 1700,
        }
      );
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    var isValid = validateForm();
    var questionsValid = validateForms();
    var inputListValid = validateForme();
    let dummyData = [];
    inputList.map((item) => {
      dummyData.push(item.input);
    });
    let demos = dummyData.filter(
      (item, index, arr) => arr.indexOf(item) !== index
    );
    if (demos.length > 0) {
      toast.error("Already Same Answer Added!", {
        position: "top-right",
        autoClose: 1700,
      });
      return;
    }
    if (
      isValid &&
      questionsValid &&
      inputListValid &&
      questionarray.selectAns.length > 0 &&
      inputList.length > 1
    ) {
      toast.success("Successfully Quiz Submit", {
        position: "top-right",
        autoClose: 1700,
      });
      setQuizobject({
        ...quizobject,
        questions: [...quizobject.questions, { questionarray }],
      });
      dispatch(
        setQuestiosn({
          ...quizobject,
          questions: [...quizobject.questions, { questionarray }],
        })
      );
      setQuestionarray({
        question: "",
        opetionType: opetionTypes,
        opetion: [],
        selectAns: [],
      });
      setInputList([
        {
          input: "",
          id: 1,
          status: false,
        },
      ]);
      setQuizobject({
        title: "",
        questions: [],
      });
      navigate("/");
    } else {
      toast.error("Please Title field is required!", {
        position: "top-right",
        autoClose: 1700,
      });
    }
  };

  return (
    <div className="create">
      <Header />
      <div className="container">
        <div className="flex justify-center items-center mt-5">
          <form className="w-full max-w-lg" onSubmit={onSubmit}>
            <div className="flex flex-wrap -mx-3 mb-3">
              <div className="w-full px-3">
                <label
                  className="block tracking-wide text-gray-700 font-bold mb-2"
                  htmlFor="grid-text"
                >
                  Title
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="grid-text"
                  type="text"
                  placeholder="Enter Title"
                  name="title"
                  value={quizobject.title || ""}
                  onChange={onchangObject}
                />
                <span className="non-valid text-red-700">
                  {quizobject.title.length <= 0 ? formError.title : ""}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap -mx-3 mb-3">
              <div className="w-full px-3">
                <label
                  className="block tracking-wide text-gray-700 font-bold mb-2"
                  htmlFor="grid-question"
                >
                  Question
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="grid-question"
                  type="text"
                  placeholder="Enter Question"
                  name="question"
                  value={questionarray.question || ""}
                  onChange={onchangArray}
                />
                <span className="non-valid text-red-700">
                  {questionarray.question.length <= 0
                    ? formErrors.question
                    : ""}
                </span>
              </div>
              <ToastContainer />
            </div>

            <div className="flex justify-between items-center mx-auto mb-1">
              <div className="flex items-center">
                <input
                  id="default-radio-1"
                  type="radio"
                  className="w-4 h-4 cursor-pointer text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  name="radiobtn"
                  value="single"
                  checked={opetionTypes === "single"}
                  onChange={onChangopetionType}
                  required
                />
                <label
                  htmlFor="default-radio-1"
                  className="ml-2 cursor-pointer font-bold text-gray-900 "
                >
                  Single
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="default-radio-2"
                  type="radio"
                  className="w-4 h-4 cursor-pointer text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  name="radiobtn"
                  value="multiple"
                  checked={opetionTypes === "multiple"}
                  onChange={onChangopetionType}
                  required
                />
                <label
                  htmlFor="default-radio-2"
                  className="ml-2 cursor-pointer font-bold text-gray-900"
                >
                  Multiple
                </label>
              </div>
            </div>

            <div className="w-full select-none">
              {inputList.map((item, index, array) => (
                <div key={index}>
                  <div className="flex justify-center items-center">
                    <div>
                      {opetionTypes === "single" ? (
                        <div className="mt-2">
                          <input
                            id="default-radio-1"
                            type="radio"
                            checked={item.status}
                            value={single || ""}
                            onChange={(e) => onchanSingle(e, index, item.id)}
                            name="default-radio"
                            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                          />
                        </div>
                      ) : (
                        <div className="flex items-center mt-2">
                          <input
                            id="link-checkbox"
                            type="checkbox"
                            checked={item.status}
                            value={item.id || ""}
                            onChange={(e) => onChangMultiple(e, index, item.id)}
                            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                          />
                        </div>
                      )}
                    </div>
                    <div className="w-full mx-1">
                      <input
                        className="appearance-none mt-2 block w-full bg-gray-200 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        id="outlined-basic"
                        type="text"
                        placeholder="Enter Answer"
                        name="input"
                        value={item.input || ""}
                        onChange={(event) => handleInputChange(event, index)}
                      />
                      <div>
                        <span className="non-valid text-red-700">
                          {item.input?.length <= 0 ? formErrore.input : ""}
                        </span>
                      </div>
                    </div>
                    <div>
                      {index === 0 && array.length === 1 ? (
                        <div className="mt-2 flex">
                          <span
                            onClick={handleListAdd}
                            className="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                          >
                            +
                          </span>
                        </div>
                      ) : index === array.length - 1 && index !== 3 ? (
                        <div className="flex">
                          <div className="mt-2 flex mr-1">
                            <span
                              onClick={() => removeInput(item.id)}
                              className="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                            >
                              -
                            </span>
                          </div>
                          <div className="mt-2 flex">
                            <span
                              onClick={handleListAdd}
                              className="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                            >
                              +
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-2 flex mr-1">
                          <span
                            onClick={() => removeInput(item.id)}
                            className="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                          >
                            -
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center my-5 cursor-pointer select-none">
              <button
                className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                disabled
              >
                Previous
              </button>
              <span
                type="submit"
                onClick={onNextbtn}
                className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
              >
                Next
              </span>
              <button
                type="submit"
                className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Create;
