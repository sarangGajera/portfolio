import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Create from './Create/Create'
import LandingPage from './LandingPage/LandingPage'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import StartQuize from './StartQuize/StartQuize'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/create" element={<Create />} />
          <Route path="/StartQuize" element={<StartQuize />} />
        </Routes>
      </BrowserRouter>
      <ToastContainer />
    </div>
  )
}

export default App
