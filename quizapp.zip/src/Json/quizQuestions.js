var Quizdata = [
  {
    question: ' ',
    seletType: ' ',
    option: [],
    answers: []
  }
]

export default Quizdata
