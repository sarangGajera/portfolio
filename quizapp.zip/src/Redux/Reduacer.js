import { createSlice } from '@reduxjs/toolkit'

const quizeUser = createSlice({
  name: 'user',
  initialState: {
    question: []
  },
  reducers: {
    setQuestiosn: (state, actions) => {
      state.question.push(actions.payload)
    },
    setDeleteQuize: (state, { payload }) => {
      const index = state.question.findIndex(item => item.id === payload)
      if (index !== -1) {
        state.question.splice(index, 1)
      }
    }
  }
})
export const { setQuestiosn, setDeleteQuize } = quizeUser.actions
export default quizeUser.reducer
