import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { setDeleteQuize } from '../Redux/Reduacer'
import { toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

const Dashboard = () => {
  const dispatch = useDispatch()
  const { question } = useSelector(state => state.quize)
  const [deleteData, setDeleteData] = useState()
  const navigate = useNavigate()

  const startPageHandler = data => {
    navigate('/StartQuize', { state: data })
  }
  useEffect(() => {
    const data = question
    if (data) {
      setDeleteData(data)
    }
  }, [])

  const handleDelete = id => {
    dispatch(setDeleteQuize(id))
    toast.success('This Quize Delete Successfully.', {
      position: 'top-right',
      autoClose: 1000
    })
  }

  return (
    <div>
      <div className="container my-12">
        <Link to="/create">
          <div className="flex justify-end items-end">
            <button className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded m-2">
              Create
            </button>
          </div>
        </Link>
        {!deleteData?.length ? (
          <div className="mx-auto flex justify-center items-center">
            <h1 className="text-black text-4xl font-semibold">No Quize</h1>
          </div>
        ) : (
          <div className="">
            {deleteData?.map((item, index) => {
              return (
                <div className="flex" key={index}>
                  <div className="block w-full h-auto p-4 border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 my-2">
                    <div className="">
                      <span className="text-black text-lg font-semibold mr-2">Title: </span>
                      {item.title}
                    </div>
                    <div className="">
                      <span className="text-black text-lg font-semibold mr-2">Que: </span>
                      {item.questions.length}
                    </div>
                    <div className="flex justify-end items-end">
                      <button
                        className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded m-2 -mt-14"
                        onClick={() => startPageHandler(item)}
                      >
                        Start
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-center items-center">
                    <button
                      className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded m-2"
                      onClick={() => handleDelete(item.id)}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

export default Dashboard
