import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import Footer from '../Component/Footer'
import Header from '../Component/Header'
const StartQuize = () => {
  const [activeQuestion, setActiveQuestion] = useState(0)
  const [questionData, setQuestionData] = useState()
  const [title, setTitle] = useState('')
  const [score, setScore] = useState(0)
  const [length, setLength] = useState(1)
  const [dummyData, setDummyData] = useState([])

  const { state } = useLocation()
  // console.log('state👍', state)

  useEffect(() => {
    setQuestionData(state.questions)
    setTitle(state.title)
  }, [])

  const handleOnChange = id => {
    if (dummyData.includes(id)) {
      let dummyFilter = dummyData.filter(item => item !== id)
      setDummyData(dummyFilter)
    } else {
      setDummyData([...dummyData, id])
    }
  }

  const nextClickHendler = count => {
    if (length <= questionData.length) {
      if (dummyData.length > 0) {
        if (dummyData.sort().join(',') === questionData[count]?.questionarray.selectAns.join(',')) {
          setScore(score + 1)
        }
      }
    }
    setLength(length + 1)

    if (questionData.length === activeQuestion + 1) {
      setQuestionData()
    } else {
      setActiveQuestion(activeQuestion + 1)
    }
    setDummyData([])
  }

  return (
    <div>
      <Header />
      {questionData?.length > 0 ? (
        <div className="container">
          <div className="">
            <div className="flex justify-center items-center">
              <div className="">
                <span className="text-black text-lg font-semibold mr-12">Title:</span>
                {title}
                <>
                  <div>
                    <div className="flex mt-12">
                      <span className="text-black text-lg font-semibold mr-3">
                        Que: {activeQuestion + 1}
                      </span>
                      <p className="mt-1">{questionData[activeQuestion]?.questionarray.question}</p>
                    </div>
                  </div>
                  {questionData[activeQuestion]?.questionarray.opetion?.map((opetion, index) => {
                    return (
                      <>
                        <div className="flex" key={index}>
                          <div className="">
                            {questionData[activeQuestion]?.questionarray.opetionType ===
                            'single' ? (
                              <div className="mt-2">
                                <input
                                  id="default-radio-1"
                                  type="radio"
                                  name="selectValue"
                                  value={opetion.input}
                                  checked={dummyData.includes(opetion.id)}
                                  onChange={() => handleOnChange(opetion.id)}
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                />
                              </div>
                            ) : (
                              <div className="flex items-center mt-2">
                                <input
                                  id="link-checkbox"
                                  type="checkbox"
                                  value={opetion.input}
                                  checked={dummyData.includes(opetion.id)}
                                  onChange={() => handleOnChange(opetion.id)}
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                />
                              </div>
                            )}
                          </div>
                          <div className="">
                            <p className="my-1 ml-4">{opetion.input}</p>
                          </div>
                        </div>
                      </>
                    )
                  })}
                </>
              </div>
            </div>
            <div className="flex justify-center items-center">
              <button
                type="submit"
                className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                onClick={() => nextClickHendler(activeQuestion, length)}
              >
                {activeQuestion === questionData.length - 1 ? 'Finish' : 'Next'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="container mx-auto flex justify-center items-center my-12">
          <div>
            <span className="text-6xl text-indigo-700">
              Total Question: {state.questions.length}
            </span>
          </div>
          <div>
            <span className="text-6xl text-green-700">Correct Answers: {score}</span>
          </div>
        </div>
      )}
      <Footer />
    </div>
  )
}
export default StartQuize
