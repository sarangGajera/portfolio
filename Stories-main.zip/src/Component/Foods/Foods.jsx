import React from 'react'
import Navbar from '../Navbar/Navbar'
import Subcribe from '../Subcribe/Subcribe'
import Footer from '../Footer/Footer'
import './foods.css'
import Foodpage from '../Pages/Foodpage/Foodpage'

const Foods = () => {
    return (
        <div className='foodss'>
           <Foodpage/>
        </div>
    )
}

export default Foods