import React from 'react'
import NavBar from './NavBar'
import SinapPage from './SinapPage'
import AddIblog from './AddIblog'
import { Route, Routes } from 'react-router-dom'
import StudentGetData from './StudentGetData'
import Studentditel from './Studentditel'
import Blog from './Blog'
import Editblog from './Editblog'
import View from './View'
import Profile from './Profile'
import Login from './Login'

const App = () => {
  return (
    <>
    <NavBar/>
    
    <Routes>
    
      <Route exact path='/' element={<StudentGetData/>} />
      <Route exact path='/sinaap' element={<SinapPage/>} />
      <Route exact path='/blog' element={<Blog/>} />
      <Route exact path='/blogs' element={<AddIblog/>} />
      <Route exact path='/studentditel/:id' element={<Studentditel/>} />
      <Route exact path='/user/:id' element={<Editblog/>} />
      <Route exact path='/users/:id' element={<View/>} />
      <Route exact path='/profile' element={<Profile/>} />
      <Route exact path='/login' element={<Login/>} />
      </Routes>
    </>
  )
}

export default App