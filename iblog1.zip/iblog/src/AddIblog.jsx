import axios from 'axios'
import React, { useState } from 'react'
import { BaseUrl } from './Baseurl'
// import { NavLink } from 'react-router-dom'

const AddIblog = () => {

  const [blog, setBlog] = useState({
    title: '',
    description: '',
    author: '',
    date: '',
    category: 'travelling',
  })


  const Inputeve = (event) => {
    const name = event.target.name
    const value = event.target.value

    console.log(name, value);


    setBlog({ ...blog, [name]: value })
  }

  const onSubmit = async (event) => {
    event.preventDefault()
    console.log(blog)


    await axios.post(`${BaseUrl}/blog/blogInsert`, blog)
      .then((res) => {
        console.log(res)
        setBlog({
          title: '',
          description: '',
          author: '',
          date: '',
          category: '',
        })
      })
      .catch((error) => {
        console.log(error)
      })
  }




  return (
    <>
      <h1 className='text-center m-5'>User iBlog</h1>
      <form onSubmit={onSubmit}>
        <div className="form-group">
          <label for="exampleInputTitle1">Title</label>
          <input type="text" required className="form-control" name='title' value={blog.title} onChange={Inputeve} id="exampleInputTitle1" aria-describedby="titleHelp" placeholder="Enter Titlt" />
        </div>
        <div className="form-group">
          <label for="exampleInputDescription1">Description</label>
          <input type="text" required className="form-control" name='description' value={blog.description} onChange={Inputeve} id="exampleInputDescription1" placeholder="Enter Description" />
        </div>
        <div className="form-group">
          <label for="exampleInputAuthor1">Author</label>
          <input type="text" required className="form-control" name='author' value={blog.author} onChange={Inputeve} id="exampleInputAuthor1" placeholder="Enter Author" />
        </div>
        <div className="form-group">
          <label for="date">Date</label><br />
          <input type="date" required id="date" name="date" value={blog.date} onChange={Inputeve} />
        </div>
        {/* <div className="form-group">
          <label for="exampleInputCategory1">Category</label>
          <input type="text" required className="form-control" name='category' value={blog.category} onChange={Inputeve} id="exampleInputCategory1" placeholder="Enter Category" />
        </div> */}

        <div className="dropdown mt-3">
          <label for="category">Choose a car:</label> <br/>

          <select name="category" id="cars" className='width' value={blog.category} onChange={Inputeve}>
            <option value="travelling">travelling</option>
            <option value="foodblog">foodblog</option>
            <option value="lifestyle">lifestyle</option>
            <option value="presonle">presonle</option>
            <option value="health and fitness">health and fitness</option>
            <option value="fashion and beauty">fashion and beauty</option>
            <option value="study">study</option>
            <option value="News">News</option>
            <option value="Sports">Sports</option>
            <option value="moves">moves</option>
            <option value="Musi">Musi</option>
          </select>
        </div>

        <button type="submit" className="btn btn-primary mt-4">Submit</button>
      </form>
    </>
  )
}

export default AddIblog