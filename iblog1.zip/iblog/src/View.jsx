import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
import { BaseUrl } from './Baseurl'
import { width } from '@mui/system'


const View = () => {

    const { id } = useParams()
    console.log(id)

    const [student, setStudent] = useState([])

    const studentData = async (id) => {
        const res = await axios.get(`${BaseUrl}/blog/blogViewById/${id}`)
            .then((r) => {
                console.log(r.data.info)
                setStudent(r.data.info)

            }).catch((error) => {
                console.log(error)
            })

    }

    useEffect(() => {
        studentData(id)
    }, []);

    return (
        <>
            <div className="card border-success mb-3" style={{maxWidth:'50rem'}}>
                <div className="card-header bg-transparent border-success">Title: {student.title}</div>
                <div className="card-footer bg-transparent border-success">Category: {student.category}</div>
            </div>
        </>
    )
}

export default View