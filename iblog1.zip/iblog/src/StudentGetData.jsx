import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { NavLink } from 'react-router-dom'
import { BaseUrl } from './Baseurl'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import { useNavigate } from 'react-router-dom'
import * as Yup from 'yup'
// import { Construction } from '@mui/icons-material'



const initialValues = {
  email: "",
  username: "",
  password: "",
  gender: "male",
  age: "",
  flied: ""
}


const StudentGetData = () => {
  const Navigate = useNavigate();

  var x = localStorage.getItem("token");

  console.log("get", x)


  

  const [search, setSearch] = useState({
    categories: ""
  })

  const [storeData, setSoreData] = useState([])

  const onInput = (e) => {
    const { name, value } = e.target
    setSearch({ ...search, [name]: value })
  }

  const onSearch = async () => {
    console.log("first", search)
    const data = await axios.post(`${BaseUrl}/blog/blogByCategories`, search).then((res) => {
      console.log("OUTPUT", res.data.info)
      setSoreData(res.data.info)

    }).catch((err) => {
      console.log(err)
    })
  }

  console.log("STORE data", storeData)
  const onSubb = (e) => {
    e.preventDefault()
    onSearch()
  }



  const [student, setStudent] = useState([])
  const studentData = async () => {
    const res = await axios.get(`${BaseUrl}/blog/blogViewAll`)
      .then((r) => {
        console.log(r.data.data)
        setStudent(r.data.data.reverse())
      }).catch((error) => {
        console.log(error)
      })
  }

  useEffect(() => {
    studentData()
  }, []);



  /////////////////////////////////////postData////////////////////////////////////////////



  // const onSubmit = values => {
  //   console.log("formik values",values)
  // }



  const validationSchema = Yup.object({
    email: Yup.string().email('Invalid  email fromat').required('Required!'),
    username: Yup.string().required('Required!'),
    password: Yup.string().required('Required!'),
    gender: Yup.string().required('Required!'),
    age: Yup.string().required('Required!'),
    flied: Yup.string().required('Required!')
  })







  const onSubmit = async (value) => {
    console.log(value)

    // await axios.post(`${BaseUrl}/user/userRegistration`, value)
    //   .then((res) => {
    //     console.log(res);
    //     Navigate("/login");
    //   })
    //   .catch((error) => {
    //     console.log(error)
    //   })
  }

 

  // }



  return (
    <>
      <div>

        {/* <input type='text' placeholder='Search ...' onChange={
      e =>onChangeHandler(e.target.value)} value={text}/> */}

        <div className='from'>
          <from>
            <input className='input' type='text' placeholder='Search ...' name='categories' value={search.categories} onChange={onInput} />
            <button className='but' type='submit' onClick={onSubb}>Submit</button>
          </from>
        </div>

      </div>
      {
        (x == null) ?
          <div className='hello'>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              <Form>
                <div className="form-group">
                  <label for="exampleInputEmail1" className='mb-2'>Email address</label>
                  <Field type="email" className="form-control" name='email' id="input_div exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                  <ErrorMessage name='email'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>
                <div className="form-group">
                  <label for="exampleInputUsername1" className='mb-2'>User Name</label>
                  <Field type="text" className="form-control" name='username' id="input_div exampleInputUsername1" aria-describedby="usernameHelp" placeholder="Enter User Name" />
                  <ErrorMessage name='username'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>
                <div className="form-group">
                  <label for="exampleInputPassword1" className='mb-2'>Password</label>
                  <Field type="password" className="form-control" name='password' id="input_div exampleInputPassword1" placeholder="Password" />
                  <ErrorMessage name='password'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>
                <div className='from-group'>
                  <label for="cars">Gender</label><br />
                  <select name="cars" id="cars">
                    <option value="Male">Male</option>
                    <option value="Fimale">Fimale</option>
                  </select>
                  <ErrorMessage name='gender'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>
                <div className="form-group">
                  <label for="exampleInputage1" className='mb-2'>Age</label>
                  <Field type="number" className="form-control" name='age' id="input_div exampleInputage1" placeholder="Enter Age" />
                  <ErrorMessage name='age'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>

                <div className="form-group">
                  <label for="exampleInputfild1" className='mb-2'>Fild</label>
                  <Field type="text" className="form-control" name='flied' id="input_div exampleInputfild1" placeholder="Enter Fild" />
                  <ErrorMessage name='flied'>{(errorMsg) => <div className='error'>{errorMsg}</div>}</ErrorMessage>
                </div>

                <button type="submit" className="btn btn-primary mt-3">Submit</button>
              </Form>
            </Formik>
          </div>

          : <div className='blanck'>hello</div>
      }



      {
        (storeData.length > 0) ? (

          <div>
            {
              storeData.map((daata, ind) => (
                <div key={ind} className="zxc my-3 w-50 p-3 d-flex justify-content-between">
                  <div>
                    <h5 className='font-weight-bold mb-4'>Title: {daata.title}</h5>
                    <h5>Category: {daata.category}</h5>
                    <h5>Date: {daata.date}</h5>
                    <h5>Description: {daata.description}</h5>
                  </div>
                  <div className='d-flex justify-content-center align-items-center images_div'>
                    <img src='/images/domenico-loia-hGV2TfOh0ns-unsplash.jpg' alt='images' />
                  </div>
                </div>
              ))
            }
          </div>




        ) : (<div> {
          student.map((data, ind) => (
            <div key={ind} className='container'>
              <div className='row'>
                <div className={`${!x ? "col-lg-8" : "col-lg-12"}`}>
                  <NavLink to={`${!x ? "/login" : `/Studentditel/${data._id}`}`} className="navelink">
                    <div className='d-flex justify-content-between zxc my-3 p-3'>
                      <div className='title_div'>
                        <h5 className='font-weight-bold mb-4'>Title: {data.title}</h5>
                        <h5 className='m-0 text-break'>Description: {data.description}</h5>
                        <h5 className='mt-2'>author: {data.author}</h5>
                        <div>
                          <div>
                            <h5>category: {data.category}</h5>
                          </div>
                          <div className='category'>
                            <h5>date: {data.date}</h5>
                          </div>
                        </div>
                      </div>

                      <div className='d-flex justify-content-center align-items-center images_div'>
                        <img src='/images/domenico-loia-hGV2TfOh0ns-unsplash.jpg' alt='images' />
                      </div>
                    </div>
                  </NavLink>
                </div>
              </div>
            </div>
          ))}
        </div>)
      }



      {/* to={`/studentditel/${data._id}`} */}
    </>
  )
}

export default StudentGetData