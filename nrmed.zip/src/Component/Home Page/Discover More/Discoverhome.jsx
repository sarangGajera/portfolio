import React, { useEffect } from 'react'
import Discovermore from '../Discover More/Discovermore'
import Discoverfrom from './Discoverfrom'

const Discoverhome = () => {
  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  return (
    <div>
    {/* flag = {pflag} */}
        <div><Discovermore /></div>
        <div className='my-5'><Discoverfrom /></div>
        {/* subbmit = {psubbmit} */}
    </div>
  )
}

export default Discoverhome