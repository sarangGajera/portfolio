import React from 'react'
import { ourData } from '../Data'
import './ourcard.css'

const Ourdoctors = () => {
  return (
    <div className='ourdoctors'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12 col-sm-12 text-center my-3'>
            <h1>Our Doctors</h1>
            <p className='mt-4'>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod <br /> tempor incididunt ut labore et dolore.
            </p>
          </div>
        </div>
        <div className='row'>
          {
            ourData.map((vall, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='doco_divv'>
                  <div className='img_docoer'>
                  <img src={vall.image} alt='images' />
                  </div>
                  <div className='title_name'>
                       <h2 className='titlt_div'>{vall.title}</h2>
                       <h5 className='text_div'>{vall.text}</h5>
                       <div className='hr_line my-4'></div>
                       <div className='icon_div'>
                          <div className='icon'>
                          {vall.icon}
                          </div>
                          <div className='icon mx-5'>
                          {vall.iconn}
                          </div>
                          <div className='icon'>
                          {vall.icoon}
                          </div>
                       </div>
                  </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
    </div>
  )
}

export default Ourdoctors