import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { BaseUrl } from '../../BaseUrl';
import Navbar from '../../Navbar/Navbar';

const Patiendetels = () => {

    const { id } = useParams()
    console.log(id);

    const [patiendetels, setPatiendetels] = useState([])

    const PatienDetels = async (id) => {
        const res = await axios.get(`${BaseUrl}/patient/viewById/${id}`)
        .then((res) => {
            console.log("wwwwwwwwwwww",res.data.info);
            setPatiendetels(res.data.info)
        })
        .catch((error) => {
            console.log(error);
        })
    }


    useEffect(() => {
        PatienDetels(id)
    }, [])

    return (
        <div className='patiendetels'>
        <Navbar/>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 patiendetels_divv'>
                         <img className='patiendetels_img_div' src='/images/national-cancer-institute-DK--4VWK1tw-unsplash.jpg' alt='images'/>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Patiendetels