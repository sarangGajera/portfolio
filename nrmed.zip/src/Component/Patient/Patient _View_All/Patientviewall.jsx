import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { BaseUrl } from '../../BaseUrl'
import { ToastContainer, toast } from 'react-toastify';
import Footer from '../../Footer/Footer'
import Navbar from '../../Navbar/Navbar'
import './patientviewall.css'
import { NavLink, useParams } from 'react-router-dom';

const Patientviewall = () => {

   const [patientview, setPatientview] = useState([])
   const [showmor, setShowmor] = useState(3)

   const slice = patientview.slice(0, showmor);
   const loadmore = () => {
       setShowmor(showmor + showmor)
       if (patientview.length == slice.length) {
           toast.error("No show more Data", {
               position: "top-center"
           })
       }
   }

   


   const Patieview = async () => {
      const res = await axios.get(`${BaseUrl}/patient/viewAll`)
         .then((res) => {
            console.log("vvvvvvvvv", res.data.data);
            setPatientview(res.data.data)
         })
         .catch((error) => {
            console.log(error);
         })
   }

   useEffect(() => {
      Patieview()
   }, [])

   const {id} = useParams()
   console.log(id);

   return (
      <div className='patientviewall'>
         <Navbar />
         <div className='container'>
            <div className='row'>
               {
                  slice.map((eve, ind) => {
                     return (
                        <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                        <NavLink to={`/patiendetels/${eve._id}`}>
                           <div className='patient_vill'>
                              <div className='patient_img_div'>
                                 <img src='/images/national-cancer-institute-DK--4VWK1tw-unsplash.jpg' alt='images' />
                              </div>
                              <div className='patient_ditels'>
                                 <h3 className='m-0'>Name: <span className='pati_vill'>{eve.patientName}</span></h3>
                                 <h3>Address: <span className='pati_vill'>{eve.patientAddress}</span></h3>
                                 <h3>Number: <span className='pati_vill'>{eve.patientNumber}</span></h3>
                              </div>
                           </div>
                           </NavLink>
                        </div>
                     )
                  })
               }
               <button className='btn_sucess mb-5' onClick={() => loadmore()}>More</button>
            </div>
         </div>
         {/* <Footer/> */}
      </div>
   )
}

export default Patientviewall