import React, { useEffect, useState } from 'react'
import Footer from '../Footer/Footer'
import Naavbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';

const Screening = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [screening, setScreening] = useState("Blood Screening")

  const [screeningstore, setScreeningstore] = useState([])

  const screeningData = async () => {
    const body = {
      speacilization: screening
    }

    await axios.post(`${BaseUrl}/doctor/doctorByspecialization`, body)
      .then((res) => {
        console.log("Screening ressssss", res.data.data);
        setScreeningstore(res.data.data)
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    screeningData()
  }, [])

  return (
    <div className='screening'>
      <Naavbar />
      <div className='container'>
        <div className='row my-4'>
          {
            screeningstore.map((eve, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='screening_maindivv'>
                    <div className='screening_images'>
                      <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                    </div>
                    <div className='screening_divv'>
                      <h1 className='doctorr_name'>{eve.doctorName}</h1>
                      <h5>{eve.speacilization}</h5>
                      <h5>Phone: {eve.phone}</h5>
                      <hr className='line_screening my-2' />
                      <div>
                        <FacebookIcon className='twit_icon' />
                        <LinkedInIcon className='twit_icon mx-5' />
                        <TwitterIcon className='twit_icon' />
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Screening