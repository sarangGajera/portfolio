import React, { useEffect, useState } from 'react'
import Naavbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';
import Footer from '../Footer/Footer';

const Specialists = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [specialists, setSpecialists] = useState("ENT Specialists")

  const [special, setSpecial] = useState([])

  const specialistsData = async () => {
    const body = {
      speacilization: specialists
    }
    await axios.post(`${BaseUrl}/doctor/doctorByspecialization`, body)
      .then((res) => {
        console.log(res.data.data);
        setSpecial(res.data.data)
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    specialistsData()
  }, [])

  return (
    <div className='specialists'>
      <Naavbar />
      <div className='container'>
        <div className='row my-4'>
          {
            special.map((eve, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='specialists_manedivv'>
                    <div className='specialists_images'>
                      <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                    </div>
                    <div className='specialists_divv'>
                      <h1 className='specialists_namee'>{eve.doctorName}</h1>
                      <h5>{eve.speacilization}</h5>
                      <h5>Phone: {eve.phone}</h5>
                      <hr className='linne_divv my-2' />
                      <div className='iconss_divv'>
                        <FacebookIcon className='iconss' />
                        <LinkedInIcon className='mx-5 iconss' />
                        <TwitterIcon className='iconss' />
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Specialists