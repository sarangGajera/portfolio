import React, { useEffect } from 'react'
import Home from '../Home Page/Home'
import Modernclinic from '../Modern Clinic/Modernclinic'
import Departments from '../Departments/Departments'
import Qualityhealth from '../Quality Health/Qualityhealth'
import Emergency from '../Emergency/Emergency'
import Footer from '../Footer/Footer'
import Countup from '../CountUp D.P.A.H/Countup'
import Bookappointment from '../BookAppointment/Bookappointment'
const Homemane = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  return (
    <>
      <div><Home/></div>
      <div className='my-5'><Countup/></div>
      <div className='my-5'><Modernclinic/></div>
      <div><Departments/></div>
      <div className='my-5'><Bookappointment/></div>
      <div className='my-5'><Qualityhealth/></div>
      <div className='mt-5'><Emergency/></div>
      <div><Footer/></div>
    </>
  )
}

export default Homemane