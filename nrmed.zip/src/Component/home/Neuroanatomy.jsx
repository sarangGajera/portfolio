import React, { useEffect, useState } from 'react'
import Footer from '../Footer/Footer'
import Naavbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';

const Neuroanatomy = () => {
  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [neuroanatomy, setNeuroanatomy] = useState("Neuroanatomy")

  const [neuroanatomystore, setNeuroanatomystore] = useState([])


  const neuroanatomyData = async () => {
    const body = {
      speacilization: neuroanatomy
    }
    await axios.post(`${BaseUrl}/doctor/doctorByspecialization`, body)
      .then((res) => {
        console.log("Neuroanatomy resssss",res.data.data);
        setNeuroanatomystore(res.data.data)
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    neuroanatomyData()
  }, [])


  return (
    <div className='neuroanatomy'>
      <Naavbar />
      <div className='container'>
        <div className='row my-4'>
          {
            neuroanatomystore.map((val, ind) => {
            return (
              <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                <div className='neuroanatomy_divv'>
                  <div className='img_neuroanatomy'>
                    <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                  </div>
                  <div className='neuroanatomy_maindivv'>
                    <h1 className='doctore_namee'>{val.doctorName}</h1>
                    <h5>{val.speacilization}</h5>
                    <h5>Phone: {val.phone}</h5>
                    <hr className='line_neuroanatomy my-2' />
                    <div>
                      <FacebookIcon className='link_divv' />
                      <LinkedInIcon className='link_divv mx-5' />
                      <TwitterIcon className='link_divv' />
                    </div>
                  </div>
                </div>
              </div>
            )
          })
          }
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Neuroanatomy