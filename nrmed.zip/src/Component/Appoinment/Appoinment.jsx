import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { BaseUrl } from '../BaseUrl'
import Footer from '../Footer/Footer'
import Naavbar from '../NavBar-1/Naavbar'
import './appoinment.css'

const Appoinment = () => {

    useEffect(() => {
        window.scrollTo({ top: 0, left: 0, });
    }, []);

    const [appoinment, setappoinment] = useState({
        patientName: "",
        doctorName: "",
        patientAddress: "",
        patientNumber: "",
        patientEmail: "",
        // doctorNumber: "",
        deases: "",
        ambulance: "",
        date: "",
        book: "",
        city: "",
        state: "",
        country: "India"
    })

    const onappoi = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setappoinment({ ...appoinment, [name]: value })
    }


    const onsubapp = async (event) => {
        event.preventDefault()
        console.log(appoinment)

        await axios.post(`${BaseUrl}/appoinment/appoinmentInsert`, appoinment)
            .then((e) => {
                console.log("hello Appoinment", e)
                setappoinment({
                    patientName: "",
                    doctorName: "",
                    patientAddress: "",
                    patientNumber: "",
                    patientEmail: "",
                    // doctorNumber: "",
                    deases: "",
                    ambulance: "",
                    date: "",
                    book: "",
                    city: "",
                    state: "",
                    country: "India"
                })
            })
            .catch((error) => {
                console.log(error)
            })
    }





    // <------------------------state---------------------------------->

    const [state, setState] = useState([])
    const arr = []
    const stateData = async () => {
        const res = await axios.get(`${BaseUrl}/stateCities/stateCitiesViewAll`)
            .then((r) => {
                setState(r.data.data)
                // console.log("hello stateData", r.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        stateData()
    }, [])


    // <------------------------country---------------------------------->

    const [country, setCountry] = useState([])


    const countryData = async () => {
        const res = await axios.get(`${BaseUrl}/country/countryViewAll`)
            .then((r) => {
                setCountry(r.data.data)
                // console.log("hello countryData", r.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        countryData()
    }, [])


    //-----------------------------------doctorData-------------------------------------

    const [doctornamee, setDoctornamee] = useState([])

    const doctorData = async () => {
        const res = await axios.get(`${BaseUrl}/doctor/viewAll`)
            .then((res) => {
                console.log("hello", res.data.data)
                setDoctornamee(res.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        doctorData()
    }, [])


    return (
        <div className='appoinment'>
            <Naavbar />
            <div class="main-bg">
                <div class="bg-wrapper">
                    <div class="dots-1 dots">
                        <div class="dots-2 dots">
                            <div class="dots-3 dots">
                                <div className='container'>
                                    <div className='row my-4'>
                                        <div className='col-md-12 col-sm-12'>
                                            <h1 className='my-4 text-center ment'>Appoinment</h1>
                                            <form onSubmit={onsubapp}>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputPatientName1">Patient Name</label>
                                                    <input type="text" className="form-control" id="exampleInputPatientName1" name="patientName" value={appoinment.patientName} onChange={onappoi} aria-describedby="PatientNameHelp" placeholder="Enter PatientName" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputDoctorName1">Doctor Name</label>
                                                    {/* <input type="text" className="form-control" id="exampleInputDoctorName1" name="doctorName" value={appoinment.doctorName} onChange={onappoi} aria-describedby="DoctorNameHelp" placeholder="Enter DoctorName" /> */}
                                                    <select className="form-select w-100" name="doctorName" required value={appoinment.doctorName} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                        {
                                                            doctornamee.map((val, ind) => {
                                                                return (
                                                                    <>
                                                                        <option key={ind}>{val.doctorName}</option>
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </select>
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputPatientAddress1">Patient Address</label>
                                                    <input type="text" className="form-control" id="exampleInputPatientAddress1" name="patientAddress" value={appoinment.patientAddress} onChange={onappoi} aria-describedby="PatientAddressHelp" placeholder="Enter PatientAddress" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputEmail1">Patient Email</label>
                                                    <input type="email" className="form-control" id="exampleInputEmail1" name="patientEmail" value={appoinment.patientEmail} onChange={onappoi} aria-describedby="emailHelp" placeholder="Enter email" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputPatientNumber1">Patient Number</label>
                                                    <input type="tel" maxLength="10" minLength="10" onKeyPress={(event) => {
                                                        if (!/[0-9]/.test(event.key)) {
                                                            event.preventDefault();
                                                        }
                                                    }} className="form-control" id="exampleInputPatientNumber1" name="patientNumber" value={appoinment.patientNumber} onChange={onappoi} aria-describedby="PatientNumberHelp" placeholder="Enter PatientNumber" />
                                                </div>
                                                {/* <div className="form-group">
                                <label className="lable_app" for="exampleInputDoctorNumber1">Doctor Number</label>
                                <input type="number" className="form-control" id="exampleInputDoctorNumber1" name="doctorNumber" value={appoinment.doctorNumber} onChange={onappoi} aria-describedby="DoctorNumberHelp" placeholder="Enter DoctorNumber" />
                            </div> */}
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputDeases1">Deases</label>
                                                    <input type="text" className="form-control" id="exampleInputDeases1" name="deases" value={appoinment.deases} onChange={onappoi} aria-describedby="DeasesHelp" placeholder="Enter Deases" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputAmbulance1">Ambulance</label>
                                                    <input type="number" className="form-control" id="exampleInputAmbulance1" name="ambulance" value={appoinment.ambulance} onChange={onappoi} aria-describedby="AmbulanceHelp" placeholder="Enter Ambulance" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputDate1">Date</label>
                                                    <input type="date" className="form-control" id="exampleInputDate1" name="date" value={appoinment.date} onChange={onappoi} aria-describedby="DateHelp" placeholder="Enter Date" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputBook1">Book</label>
                                                    <input type="number" className="form-control" id="exampleInputBook1" name="book" value={appoinment.book} onChange={onappoi} aria-describedby="BookHelp" placeholder="Enter Book" />
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputState1">State</label>
                                                    {/* <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password"/> */}
                                                    <select className="form-select w-100" name="state" required value={appoinment.state} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">

                                                        {state.map((eve, ind) => {
                                                            if (arr.includes(eve.state)) {
                                                                arr.push(eve.state);
                                                            } else {
                                                                arr.push(eve.state);
                                                                return <option key={ind}>{eve.state}</option>
                                                            }
                                                        })}

                                                    </select>
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputCity1">City</label>
                                                    {/* <input type="text" className="form-control" id="exampleInputCity1" aria-describedby="CityHelp" placeholder="Enter City"/> */}
                                                    <select className="form-select w-100" name="city" required value={appoinment.city} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                        <option>city</option>
                                                        {state.map((val, i) => {
                                                            if (val.state == appoinment.state) {

                                                                return <option key={i}>{val.city}</option>
                                                            }
                                                        })}

                                                    </select>
                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputCountry1">Country</label>
                                                    {/* <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password"/> */}
                                                    <select className="form-select w-100" name="country" required value={appoinment.country} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                        {
                                                            country.map((val, ind) => {
                                                                return (
                                                                    <>
                                                                        <option key={ind}>{val.name}</option>
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </select>
                                                </div>
                                                <button type="submit" className="btn_app">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default Appoinment