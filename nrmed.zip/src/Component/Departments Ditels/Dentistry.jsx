import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import './Departmentsmore.css'
import Footerdepartments from './Footerdepartments'

const Dentistry = () => {
     
    useEffect(() => {
        window.scrollTo({top: 0, left: 0,});
      }, []);

    return (
        <div className='dentistry'>
            <Navbar />
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 dol-sm-12 logo_diivs'>
                        {/* <img className='imges_logo_divv' src='/images/toothh.png' alt='images' /> */}
                        <h1 className='Dentist_divv'>Dentistry</h1>
                    </div>
                </div>

                <div className='row margin_row'>
                    <div className='col-md-12 col-sm-12'>
                        <div>
                        <h1 className='mb-4 range'>Who is a Dentist ?</h1>
                        <p className='ml-5'>
                        A dentist is a doctor who specializes in teeth, gums, and the mouth. If you get a bad toothache, you should probably go to the dentist to make sure you don't have a cavity. <br/> <br/>
                            When you visit the dentist, you might have your teeth and gums examined and cleaned, or you may need surgery for an impacted wisdom tooth or x-rays to make sure you don't have cavities. Dentists are health care professionals who attend dental school and train for several years before practicing. Dentist comes from the French dentiste, from dent. or "tooth." <br/> <br/>
                            A dentist is a specialist who works to diagnose, treat, and prevent oral health problems. Your dentist has completed at least eight years of schooling, and received either a DDS (Doctor of Dental Surgery) degree, or a DMD (Doctor of Dental Medicine) degree. If your doctor is a pediatric dentist, this means that he or she specializes in caring for children from infancy through their teen years. A pediatric dentist has received the proper education and training needed to work with young kids. Other specializations include:
                        </p>
                        </div>
                        <div className='mt-5'>
                            <h1 className='mb-4'>What is Dentistry ?</h1>
                            <p className='ml-5'>
                            dentistry, the profession concerned with the prevention and treatment of oral disease, including diseases of the teeth and supporting structures and diseases of the soft tissues of the mouth. Dentistry also encompasses the treatment and correction of malformation of the jaws, misalignment of the teeth, and birth anomalies of the oral cavity such as cleft palate. In addition to general practice, dentistry includes many specialties and subspecialties, including orthodontics and dental orthopedics, pediatric dentistry, periodontics, prosthodontics, oral and maxillofacial surgery, oral and maxillofacial pathology, endodontics, public health dentistry, and oral and maxillofacial radiology.
                              <h1 className="mt-3">Early dentistry</h1>
                              Dentistry, in some form, has been practiced since ancient times. For example, Egyptian skulls dating from 2900 to 2750 BCE contain evidence of small holes in the jaw in the vicinity of a tooth’s roots. Such holes are believed to have been drilled to drain abscesses. In addition, accounts of dental treatment appear in Egyptian scrolls dating from 1500 BCE. It is thought that the Egyptians practiced oral surgery perhaps as early as 2500 BCE, although evidence for this is minimal. An early attempt at tooth replacement dates to Phoenicia (modern Lebanon) around 600 BCE, where missing teeth were replaced with animal teeth and were bound into place with cord.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <Footerdepartments/>
        </div>
    )
}

export default Dentistry