import React from 'react'
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import { NavLink } from 'react-router-dom';

const Footerdepartments = () => {

    const year = new Date().getFullYear();

    return (
        <div className='footerdepartments mt-5'>
            <div className='container'>
                <div className='row footer_mani_divv'>
                    <div className=''>
                        <div>
                            <h1>Nrmed</h1>
                            <p>
                                Health is Wealth
                            </p>
                            <div>
                                <p className='m-0'>
                                    Lorem ipsum dolor sit amet, <br />
                                    consectetur adipiscing elit, sed do <br />
                                    eiusmod tempor incididunt ut labore.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className=''>
                        <div className=''>
                            <div className='hospi'>
                            <NavLink className='nav_linenene' to='/discoverhome'><ArrowRightAltIcon /> Hospital</NavLink>
                            <NavLink className='nav_linenene' to='/doctorlogin'><ArrowRightAltIcon /> Doctore</NavLink>
                            <NavLink className='nav_linenene' to='/'><ArrowRightAltIcon /> Patient</NavLink>
                            <NavLink className='nav_linenene' to='/'><ArrowRightAltIcon /> Ambulance</NavLink>
                            </div>
                        </div>
                    </div>
                </div>
                <hr className='hr_lines' />
                <div className='row'>
                    <p className='copyright_divv ml-5'>
                        Copyright ©{year} All rights reserved | This template is Nrmed with by Colorlib
                    </p>
                </div>
            </div>
        </div>
    )
}

export default Footerdepartments