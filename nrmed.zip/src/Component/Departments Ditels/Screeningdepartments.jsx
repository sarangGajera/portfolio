import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import Footerdepartments from './Footerdepartments'

const Screeningdepartments = () => {

    useEffect(() => {
        window.scrollTo({top: 0, left: 0,});
      }, []);

    return (
        <div className='screeningdepartments'>
            <Navbar />
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 virus_divv'>
                        {/* <img className='virus_images' src='/images/viruss.png' alt='images' /> */}
                        <h1 className='scre_divv'>Blood Screening</h1>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 mt-5'>
                        <h1 className='mt-5 range'>Who is a Blood Screening</h1>
                        <p className='mt-4 ml-5'>
                            Blood tests can give your healthcare provider a lot of information. He or she can see if certain elements in your blood are in a normal range. But in many cases, blood tests are only part of the information your healthcare provider needs to make a diagnosis of a health condition. You might need to have some other types of tests as well. <br /><br />
                            For most kinds of blood tests, you don't need to prepare. These tests are to see what your blood is like under normal conditions. <br /><br />

                            For some blood tests, you will have to not eat (fast) for a certain amount of time before the blood test. This usually means no eating or drinking anything after midnight before the test. These tests are often scheduled for early in the morning. <br /><br />

                            Your healthcare provider will let you know if you need to fast before a blood test. <br /><br />
                            In order to test your blood, a technician called a phlebotomist will use a needle to take a sample of blood. Tell the technician if the sight of needles makes you nervous. He or she can help you feel more at ease. You can also look away during the procedure, and bring a family member or friend to help distract you. <br /><br />

                            In most cases, the sample is taken from a vein in your arm. You will be seated or lying down. You may be asked to make a fist. The technician will tie a rubber band around your arm. Once he or she sees a vein, the technician will clean the area and then insert the needle. You might feel a small prick. Once the technician has drawn enough blood, he or she will take the needle out and put an adhesive bandage over the site. You may be asked to press firmly on the site to stop any bleeding. <br /><br />
                            Your blood sample will be sent to a lab. Trained technicians then look for the information the healthcare provider has ordered. This may take a day or up to a week or more. Check back with your healthcare provider’s office to find out about the results.
                        </p>
                        <h1 className='mt-5'>What is Blood Screening</h1>
                        <p className='ml-5 mt-4'>
                            The screening of donated blood and the quarantine of blood and blood components represent critical processes that should be followed to ensure that blood units are safe. Based on the screening results, they should either be released for clinical or manufacturing use or be discarded. Laboratory screening for TTIs should be performed on blood samples collected at the time of donation. All tests on blood samples should be performed and recorded in accordance with standardized procedures in laboratories that are properly equipped to undertake them. <br /><br />

                            All blood samples, donations and components should be correctly labelled to ensure correct identification throughout the screening process. The BTS should also have appropriate, validated systems for linking all test results to the correct donations and donors so that donors' records can be reviewed each time they come to donate. These systems will ensure that the correct results are allocated to each donation and prevent errors resulting in the transfusion of an unsafe unit. <br /><br />

                            Laboratory staff should always adhere to the national screening strategy, algorithm and standardized procedures when conducting the tests and analysing the results. The performance of laboratory tests in a quality environment with competent staff and a functional documentation system will minimize the risk of analytical and transcription errors, particularly false negative results. <br /><br />

                            The objective of blood screening is to detect markers of infection in order to prevent the release of infected blood and blood components for clinical use. Blood screening strategies are designed to assure the safety of blood units, but should not be used for notifying blood donors of reactive test results. The appropriate confirmatory testing strategy for blood donor management should be applied before notifying donors of their infectivity status (see Section 6). The results of all tests performed for infection markers for TTIs and blood group serology should be evaluated when making final decisions on the release of blood units for therapeutic use. <br /><br />

                            routinely screen for TTI markers (HIV antigen-antibody, HBsAg, anti-HCV and syphilis) at the same time. The main reason for this is to reduce the time needed for screening so that the blood or blood components, especially labile components such as platelets, can be released in a timely manner. Initially reactive donations are segregated and quarantined. Depending on the algorithm used by the laboratory, the donation is then either discarded or repeat testing is performed. <br /><br />

                            Some laboratories may use sequential screening by initially testing for one or two infection markers. If a reactive result is obtained, no further testing is performed on this donation. The screening strategy for determining the test or tests that are undertaken first will be influenced by the prevalence of infections in the blood donor population. Sequential screening is sometimes used in countries where the prevalence of one TTI is higher than others; for instance, HBsAg might be screened for first when the prevalence of hepatitis B is higher than the prevalence of HIV and HCV. In this situation, only HBsAg negative donations would then be tested for HIV antigen-antibody, anti-HCV and syphilis. No tests for these viral markers would be performed on the donations that test reactive on the HBsAg screening test. Thus there is potential for cost savings, especially if the more expensive assays do not need to be performed on donations that have already tested positive for HBsAg. <br /><br />

                            While sequential testing may be perceived to have economic benefits, the potential cost savings need to be balanced against factors such as the increased turnaround time for results and increased staff costs owing to longer shifts. It may result in delays in screening and releasing blood and blood components, leading to poor blood stocks, especially if there are chronic shortages. Another disadvantage of this strategy is that donors with co-infections (i.e. with more than one infection) will not be identified and cannot, therefore, be notified and counselled about these additional infections as part of the duty of care towards blood donors. Sequential testing could also increase the possibility of mix-ups and errors owing to frequent handling of blood samples, donations or the components derived from them. In centres with limited or no quality systems, this might lead to an increased risk of untested or unsafe units being transfused. The opportunity to study the epidemiological profile of infections in donors will also be lost. Sequential screening is therefore not recommended for a blood screening programme. <br /><br />
                        </p>
                    </div>
                </div>
            </div>
            <Footerdepartments/>
        </div>
    )
}

export default Screeningdepartments