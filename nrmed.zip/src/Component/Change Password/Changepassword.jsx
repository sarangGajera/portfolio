import React from 'react'
import './changepassword.css'
import HttpsIcon from '@mui/icons-material/Https';
import LockIcon from '@mui/icons-material/Lock';

const Changepassword = () => {
    return (
        <div className='changepassword'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>
                        <div className='changepassword_maindivv'>
                            <div>
                                <HttpsIcon className='mb-4' sx={{ fontSize: 80 }} />
                            </div>
                            <div>
                                <h1 className='text-center mb-4'>New <br />Password</h1>
                            </div>
                            <div>
                                <form>
                                    <div className='password_divv'>
                                        <LockIcon className='mx-3' />
                                        <input type="password" id="pwd" name="pwd" minlength="8" placeholder='Enter Password' />
                                    </div>
                                    <div className='password_divv my-4'>
                                        <LockIcon className='mx-3' />
                                        <input type="password" id="pwd" name="pwd" minlength="8" placeholder='Enter Confirm Password' />
                                    </div>
                                    <button className='pass_sub'>submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Changepassword