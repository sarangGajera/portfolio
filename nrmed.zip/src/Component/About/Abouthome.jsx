import React, { useEffect } from 'react'
import Emergency from '../Emergency/Emergency'
import Footer from '../Footer/Footer'
import Modernclinicc from '../Modern Clinic/Modernclinicc'
import Qualityhealth from '../Quality Health/Qualityhealth'
import About from './About'

const Abouthome = () => {
  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);
 
  return (
    <>
      <About/>
      <Modernclinicc/>
      <div className="mt-5"><Qualityhealth/></div>
      <Emergency/>
      <Footer/>
    </>
  )
}

export default Abouthome