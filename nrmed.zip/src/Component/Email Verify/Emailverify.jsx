import axios from 'axios'
import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { BaseUrl } from '../BaseUrl'
import './emailverify.css'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { toast } from 'react-toastify';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const Emailverify = () => {

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const [password, setpPassword] = useState()

    const Navigate = useNavigate()

    const [emailverify, setEmailverify] = useState({
        email: "",
        otp: "",
    })


    const EmailVery = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setEmailverify({ ...emailverify, [name]: value })
    }

    const otpVerify = async (event) => {
        event.preventDefault()
        console.log(emailverify)

        await axios.post(`${BaseUrl}/doctor/emailverify`, emailverify)
            .then((res) => {
                console.log(res.data.data);
                setpPassword(res.data.data)
                if (res.data.status === 200) {
                    handleOpen()
                }
                setEmailverify({
                    email: "",
                    otp: "",
                })

            })
            .catch((err) => {
                console.log(err);
            });
    }


    //----------------------------------ConfirmPassword----------------------------------------->

    const [passwordcon, setPasswordcon] = useState({
        password: "",
        confirmPassword: "",
    })

    const passwcon = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setPasswordcon({ ...passwordcon, [name]: value })
    }

    const ConPassword = async (event) => {
        event.preventDefault()
        console.log(passwordcon)

        await axios.put(`${BaseUrl}/doctor/changePassword/${password}`, passwordcon)
            .then((res) => {
                console.log("hellooodddddddd", res);
                if (res.data.status === 200) {
                    toast.success("Successfully Password", {
                        position: "top-right"
                    })
                }
                Navigate("/")
                setPasswordcon({
                    password: "",
                    confirmPassword: "",
                })
            })
            .catch((error) => {
                console.log("shdbvsuygfsiyfb",error.response.status);
                if (error.response.status === 400) {
                    toast.error("Enter the velid Password", {
                        position: "top-right"
                    })
                }
            })
    }



    const [passwordShown, setPasswordShown] = useState(false);
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };

    return (
        <div className='emailverify'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>
                        <div className='email_divv'>
                            <h1 className='text-center email_text mb-5'>Email Verify</h1>
                            <form onSubmit={otpVerify}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" required class="form-control" name='email' value={emailverify.email} onChange={EmailVery} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputtel1">OTP</label>
                                    <input required type="tel" maxLength="6" minLength="4" name='otp' value={emailverify.otp} onChange={EmailVery} onKeyPress={(event) => {
                                        if (!/[0-9]/.test(event.key)) {
                                            event.preventDefault();
                                        }
                                    }} class="form-control" id="exampleInputtel1" placeholder="Enter otp" />
                                </div>
                                <button type="submit" class="submit_btnn">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box className='box_divv' sx={style}>
                    <Typography>
                        <div className='password_divv'>
                            <h1 className='mb-5 text-center'>Confirm Password</h1>
                            <form onSubmit={ConPassword}>
                                <div class="form-group icon_pass_con">
                                    <label for="exampleInputPassword1">Password</label>
                                    <input type="password" class="form-control" name='password' value={passwordcon.password} onChange={passwcon} id="exampleInputPassword1" placeholder="Password" />
                                </div>
                                <div class="form-group icon_pass_con">
                                    <label for="exampleInputPassword1">Confirm Password</label>
                                    <input type={passwordShown ? "text" : "password"} name="confirmPassword" value={passwordcon.confirmPassword} onChange={passwcon} class="form-control" id="exampleInputPassword1" placeholder="Password" />
                                    <i className='Pass_confirm' onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</i>
                                </div>
                                <button type="submit" class="btn_password">Submit</button>
                            </form>
                        </div>
                    </Typography>
                </Box>
            </Modal>
        </div>
    )
}

export default Emailverify