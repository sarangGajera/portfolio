import React from 'react'
import { NavLink } from 'react-router-dom'
import './Modernclinic.css'

const Modernclinic = () => {
  return (
    <div className='container'>
        <div className='row'>
           <div className='col-md-6 col-sm-6'>
            <div className='color_div'> </div>
            <img className='imag_modern' src='/images/ashkan-forouzani-DPEPYPBZpB8-unsplash.jpg' alt='images'/>
           
           </div>
           <div className='modern_div col-md-6 col-sm-6'>
               <h1 className='welcom_div'>Welcome to <br/>
                  <span className='clinic_div'>Nrmed</span>
               </h1>
               <p className='my-4'>
               Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veni.
               </p>
               <div>
                    <p><span className='right_icon'>✓</span>Lorem ipsum dolor sit amet</p>
                    <p><span className='right_icon'>✓</span>Consectetur adipisicing elit, sed do</p>
                    <p><span className='right_icon'>✓</span>Eiusmod tempor incididunt ut labore</p>
               </div>
               <NavLink to='/about' className='mt-4 btn_about'>About Us</NavLink>
           </div>
        </div>
    </div>
  )
}

export default Modernclinic