import React from 'react'
import './footer.css'
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import GoogleIcon from '@mui/icons-material/Google';
import InstagramIcon from '@mui/icons-material/Instagram';

const Footer = () => {
    const year = new Date().getFullYear();
    return (
        <div className='footer'>
            <div className='container'>
            <div className='mani_footer'>
                  <div>
                  <div className=''>
                       <div className='logo_nrmed'> <LocalHospitalIcon sx={{ fontSize: 50 }}/> Nrmed</div>
                        <p className='ipsum_div mt-4'>
                            Lorem ipsum dolor sit amet, <br/>
                            consectetur adipiscing elit, sed do <br/>
                            eiusmod tempor incididunt ut labore.
                        </p>
                        <div className='ml-2 icon_socilo'>
                            <a href='https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C589460569900%7Ce%7Cfacebook%20login%7C&placement=&creative=589460569900&keyword=facebook%20login&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696221912%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1409285535%26loc_physical_ms%3D9062198%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=Cj0KCQjwxIOXBhCrARIsAL1QFCaQGwdUR6NIXSesULqxQY1QsPg243PjSzrvvzuEKhk2r77aPZxXH24aAh4DEALw_wcB' target="_blank"><FacebookIcon className='icons'/></a>
                            <a href='https://twitter.com/i/flow/login' target="_blank"><TwitterIcon className='mx-3 icons'/></a>
                            <a href='https://play.google.com/store/apps/details?id=com.google.android.apps.chromecast.app&hl=gu&gl=US' target="_blank"><GoogleIcon className='icons'/></a>
                            <a href='https://www.instagram.com/accounts/login/' target="_blank"><InstagramIcon className='ml-3 icons'/></a> 
                        </div>
                    </div>
                  </div>
                  <div>
                  <div className=''>
                        <div className='our_divv'>
                        <h4 className='mt-3'>Our Departments</h4>
                        </div>
                        <div className='d-flex mt-4 births'>
                        <div>
                            <h6>Births</h6>
                            <h6>Cardiology</h6>
                            <h6>Traumatology</h6>
                            <h6>Nuclear</h6>
                            <h6>Pregnancy</h6>
                            <h6>X-ray</h6>
                        </div>
                        <div style={{marginLeft:"50px"}}>
                            <h6>Pulamonary</h6>
                            <h6>Neurology</h6>
                            <h6>Dental</h6>
                            <h6>magnetic</h6>
                            <h6>For disabled</h6>
                            <h6>Prostheses</h6>
                        </div>
                        </div>
                    </div>
                  </div>
                  <div>
                  <div className=''>
                        <div className='avail_divv'>
                        <h4 className=''>We’re Available</h4>
                        </div>
                        <div className='mt-4 monday_div'>
                            <h6>Monday - Friday</h6>
                            <h6>Saturday</h6>
                            <h6>Sunday</h6>
                        </div>
                    </div>
                  </div>
                  <div>
                  <div className='time_div'>
                        <h6>8.00 - 18.00</h6>
                        <h6>8.00 - 18.00</h6>
                        <h6>8.00 - 13.00</h6>
                    </div>
                  </div>
            </div>
                <hr className='hr_line'/>
                <div>
                    <p className='copyright_divv'>Copyright ©{year} All rights reserved | This template is Nrmed with  by <a href='https://colorlib.com/' target="_blank"><span className='colorlib'>Colorlib</span></a></p>
                </div>
            </div>  
        </div>
    )
}

export default Footer