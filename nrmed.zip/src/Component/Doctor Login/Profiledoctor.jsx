import React from 'react'

const Profiledoctor = () => {
  return (
    <div>Profiledoctor</div>
  )
}

export default Profiledoctor