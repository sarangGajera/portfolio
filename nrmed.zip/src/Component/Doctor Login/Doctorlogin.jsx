import React, { useState } from 'react'
import './doctorlogin.css'
import LockIcon from '@mui/icons-material/Lock';
import PersonIcon from '@mui/icons-material/Person';
import { NavLink, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const Doctorlogin = () => {

	const navigate = useNavigate()

	const [doctorlogin, setDoctorlogin] = useState({
		email: "",
		password: ""
	})

	const login = (event) => {
		const name = event.target.name
		const value = event.target.value

		// console.log(name, value)

		setDoctorlogin({ ...doctorlogin, [name]: value })
	}

	const onSubmit = async (event) => {
		event.preventDefault()
		console.log(doctorlogin)

		await axios.post(`${BaseUrl}/doctor/login`, doctorlogin)
			.then((res) => {
				console.log("ffffffffffffff",res.data.data);
				
				navigate("/")
				if(res.data.status === 200){
					localStorage.setItem("accessToken",res.data.data)
					toast.success("Doctor Login Successfully", {
                        position:"top-right"
                    })
				}
				setDoctorlogin({
					email: "",
					password: ""
				})
			})
			.catch((error) => {
				console.log(error.response.status);
				if(error.response.status === 400){
					toast.error("Plase Enter Fild!", {
                        position:"top-right"
                    })
				}else if(error.response.status === 401){
					toast.error("Plase Enter the Velid Password!", {
                        position:"top-right"
                    })
				}
				else if(error.response.status === 401){
					toast.error("Plase Enter the Email!", {
                        position:"top-right"
                    })
				}
			})
	}


	const [passwordShown, setPasswordShown] = useState(false);
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };

	return (
		<div className='doctorlogin'>
			<div class="limiter">
				<div class="container-login100">
					<div class="wrap-login100">
						<form class="login100-form validate-form" onSubmit={onSubmit}>

							<span className="login100-form-title brand_name p-b-34 p-t-27">
								<LocalHospitalIcon sx={{ fontSize: 70 }}/>
							</span>

							<div class="wrap-input100 validate-input">

								<input className="input100" type="email" name="email" value={doctorlogin.email} onChange={login} placeholder="Enter Email" />
								<span class="focus-input100"><PersonIcon className='localHospitalIcon'/></span>
							</div>

							<div class="wrap-input100 validate-input" >
								<input class="input100" type={passwordShown ? "text" : "password"} name="password" value={doctorlogin.password} onChange={login} placeholder="Enter Password" />
								<i className='Pass_login' onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</i>
								<span class="focus-input100"><LockIcon className='localHospitalIcon'/>bbb</span>
							</div>
							<div class="container-login100-form-btn">
								<button className="form-btn">
									Login
								</button>
							</div>
							<div class="text-center pass_for my-3" >
								<NavLink to='/doctorregistration'>Signup</NavLink>
							</div>
							<div class="text-center pass_for" >
								<NavLink to='/emailverify'>Forgot Password?</NavLink>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	)
}

export default Doctorlogin