import React from 'react'
import './contact.css'
import HomeIcon from '@mui/icons-material/Home';
import PhoneAndroidIcon from '@mui/icons-material/PhoneAndroid';
import EmailIcon from '@mui/icons-material/Email';

const Contactfrom = () => {
    return (
        <div className='contactfrom'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>
                        <h3 className='mb-4'>Get in Touch With Nrmed</h3>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-8 col-sm-12'>
                        <form>
                            <div class="form-group">
                                <textarea class="form-control" id="exampleFormControlTextarea1" placeholder='Enter Message' rows="7"></textarea>
                            </div>
                            <div className='d-flex justify-content-between'>
                            <div class="form-group from_name">
                                <input type="text" class="form-control" id="exampleInputname1" placeholder="Enter your name" style={{height:"52px"}}/>
                            </div>
                            <div class="form-group from_nname">
                                <input type="email" class="form-control" id="exampleInputname1" placeholder="Email" style={{height:"52px"}}/>
                            </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="exampleInputname1" placeholder="Enter Subject" style={{height:"52px"}}/>
                            </div>
                            <button type="submit" className="btn_send">Send</button>
                        </form>
                    </div>
                    <div className='col-md-4 col-sm-12'>
                        <div className='buttonwood'>
                            <div className='buttonwd'>
                                <HomeIcon className='buttonwd_icons' sx={{ fontSize: 45 }} />
                            </div>
                            <div>
                                <h5 className='m-0'>Buttonwood, California.</h5>
                                <p className='rosemead'>Rosemead, CA 91770</p>
                            </div>
                        </div>
                        <div className='buttonwood mt-4'>
                            <div className='buttonwd'>
                                <PhoneAndroidIcon className='buttonwd_icons' sx={{ fontSize: 45 }} />
                            </div>
                            <div className='mr-5'>
                                <h5 className='m-0'>+1 253 565 2365</h5>
                                <p className='rosemead'>Mon to Fri 9am to 6pm</p>
                            </div>
                        </div>
                        <div className='buttonwood mt-4'>
                            <div className='buttonwd'>
                                <EmailIcon className='buttonwd_icons' sx={{ fontSize: 45 }} />
                            </div>
                            <div>
                                <h5 className='m-0'>support@colorlib.com</h5>
                                <p className='rosemead'>Send us your query anytime!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Contactfrom