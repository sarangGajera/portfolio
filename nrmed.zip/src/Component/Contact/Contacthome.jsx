import React from 'react'
import Footer from '../Footer/Footer'
import Contact from './Contact'
import Contactfrom from './Contactfrom'
import Googlemap from './Googlemap'

const Contacthome = () => {
  return (
    <div>
        <div><Contact/></div>
        <div className='mt-5'><Googlemap/></div>
        <div className='mt-5'><Contactfrom/></div>
        <div className='mt-5'><Footer/></div>
    </div>
  )
}

export default Contacthome