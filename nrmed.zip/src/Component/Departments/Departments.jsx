import React from 'react'
import './departments.css'
import { data, moreData } from '../Data'
import { NavLink } from 'react-router-dom'
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const Departments = () => {
    console.log(data)

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);


    return (
        <div className='departments my-5'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>
                        <div className='departments_div'>
                            <div>
                                <h1 className='header_div'>Departments</h1>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod <br /> tempor incididunt ut labore et dolore.
                                </p>
                            </div>
                            <div className='btn_learn'>
                                <Button onClick={handleOpen} className='btn_llearn'>Learn More</Button>
                                <Modal
                                    open={open}
                                    onClose={handleClose}
                                    aria-labelledby="modal-modal-title"
                                    aria-describedby="modal-modal-description"
                                >
                                    <Box sx={style}>
                                        <div className='row row_more'>
                                            {
                                                moreData.map((eve, ind) => {
                                                    return (
                                                        <div key={ind} className='col-lg-4 col-md-6 col-sm-12'>
                                                            <NavLink to={`${eve.links}`} className="tit_div">
                                                                <div className='more_divv'>
                                                                    <img className='imag_mor' src={eve.images} alt='images' />
                                                                    <h5 className='mt-3 tit_man_divv'>{eve.title}</h5>
                                                                </div>
                                                            </NavLink>
                                                        </div>
                                                    )
                                                })
                                            }
                                        </div>
                                    </Box>
                                </Modal>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='row my-5'>
                    {
                        data.map((val, ind) => {
                            return (

                                <div key={ind} className='col-lg-2  col-md-4 col-sm-12 mx-auto' >
                                    <NavLink to={`${val.link}`} className="tit_div">
                                        <div className='card_div'>
                                            <img className='images_divv' src={val.images} alt='images' />
                                            <h5 className='m-0'>{val.title}</h5>
                                        </div>
                                    </NavLink>
                                </div>

                            )
                        })
                    }
                </div>

                <div className='row my-4'>
                    <div className='col-lg-12 col-md-12 col-sm-12 dental_div'>
                        <div>
                            <img className='dental_img' src='/images/olga-guryanova-tMFeatBSS4s-unsplash.jpg' alt='images' />
                        </div>
                        <div className='dental'>
                            <h3>
                                All doctors treat, but a good doctor lets nature heal.
                            </h3>
                            <p className='my-4'>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.
                            </p>
                            <NavLink to='/appoinment'><button className='btn_make my-5'>Make An Appointment</button></NavLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Departments