import React from 'react'
import './qualityhealth.css'
import AcUnitIcon from '@mui/icons-material/AcUnit';
import { Quality } from '../Data';

const Qualityhealth = () => {


    
    return (
        <div className='qualityhealth'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 text-center'>
                        <h1>Quality Health</h1>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod <br /> tempor incididunt ut labore et dolore.
                        </p>
                    </div>
                </div>
                <div className='row my-5'>
                    
                        {
                            Quality.map((eve, ind) => {
                                return (
                                    <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                                    <div className='health_div'>
                                        <div className='div_iconn'>
                                            <img className='divv_iconn' src={eve.image} alt='images'/>
                                        </div>
                                        <h4 className='mt-4'>{eve.title}</h4>
                                        <h5 className='mt-4 lorem_div'>{eve.text}</h5>
                                    </div>
                                    </div>
                                )
                            })
                        }
                    
                </div>
            </div>
        </div>
    )
}

export default Qualityhealth