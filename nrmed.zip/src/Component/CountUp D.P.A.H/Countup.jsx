import React, { useEffect, useState } from 'react'
import './countup.css'
import CountUp from 'react-countup'
import axios from 'axios'
import { BaseUrl } from '../BaseUrl'

const Countup = () => {

    const [doctorup, setDoctorup] = useState([])

    const totlenumber = async () => {
        const res = await axios.get(`${BaseUrl}/doctor/viewAll`)
            .then((res) => {
                console.log("Countttttttttt", res.data.data.length);
                setDoctorup(res.data.data.length)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    useEffect(() => {
        totlenumber()
    }, [])




    const [patientup, setpatientup] = useState([])

    const Patientnum = async () => {
        const res = await axios.get(`${BaseUrl}/patient/viewAll`)
            .then((res) => {
                console.log("Counffffffff", res.data.data.length);
                setpatientup(res.data.data.length)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    useEffect(() => {
        Patientnum()
    }, [])



    const [ambulanceup, setambulanceup] = useState([])

    const Ambulancenum = async () => {
        const res = await axios.get(`${BaseUrl}/ambulance/ambulanceViewAll`)
            .then((res) => {
                console.log("Counhhhhhhhhh", res.data.data.length);
                setambulanceup(res.data.data.length)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    useEffect(() => {
        Ambulancenum()
    }, [])


    const [hospitalup, sethospitalup] = useState([])

    const Hospitalnum = async () => {
        const res = await axios.get(`${BaseUrl}/hospital/ViewAll`)
            .then((res) => {
                console.log("Counhhhhhhhhh", res.data.data.length);
                sethospitalup(res.data.data.length)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    useEffect(() => {
        Hospitalnum()
    }, [])

    return (
        <div className='countup'>
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-3 col-md-6 col-sm-12'>
                        <div className='countup_divv'>
                            <h1><CountUp end={doctorup}/></h1>
                            <h2>Doctor</h2>
                        </div>
                    </div>

                    <div className='col-lg-3 col-md-6 col-sm-12'>
                        <div className='countup_divv'>
                            <h1><CountUp end={patientup} duration={1} /></h1>
                            <h2>Patient</h2>
                        </div>
                    </div>

                    <div className='col-lg-3 col-md-6 col-sm-12'>
                        <div className='countup_divv'>
                            <h1><CountUp end={ambulanceup} duration={1} /></h1>
                            <h2>Ambulance</h2>
                        </div>
                    </div>

                    <div className='col-lg-3 col-md-6 col-sm-12'>
                        <div className='countup_divv'>
                            <h1><CountUp end={hospitalup} duration={1} /></h1>
                            <h2>Hospital</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Countup